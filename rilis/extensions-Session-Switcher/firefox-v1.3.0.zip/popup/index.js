"use strict";
(() => {
  // src/shared/utils/domain.ts
  function extractDomain(hostname) {
    return hostname.replace(/^www\./, "");
  }
  function getDomainFromUrl(url) {
    try {
      const urlObj = new URL(url);
      const domain = extractDomain(urlObj.hostname);
      const isLocalhost = domain === "localhost" || domain.startsWith("127.");
      const port = urlObj.port;
      if (isLocalhost && port) {
        return `${domain}:${port}`;
      }
      return domain;
    } catch (_) {
      console.error("Invalid URL:", url);
      return "";
    }
  }

  // src/shared/utils/errorHandling.ts
  var ExtensionError = class extends Error {
    constructor(message, code) {
      super(message);
      this.code = code;
      this.name = "ExtensionError";
    }
  };
  function handleError(error, context) {
    console.error(`Error in ${context}:`, error);
    if (error instanceof ExtensionError) {
      return error.message;
    }
    if (error instanceof Error) {
      return error.message;
    }
    return "An unexpected error occurred";
  }

  // src/popup/utils/constants.ts
  var CSS_CLASSES = {
    SHOW: "show",
    LOADING: "loading",
    ACTIVE: "active",
    SESSION_ITEM: "session-item",
    SESSION_BTN: "session-btn",
    NO_SESSIONS: "no-sessions"
  };
  var UI_TEXT = {
    NO_SESSIONS: "No sessions saved for this site",
    UNNAMED_SESSION: "Unnamed Session",
    LAST_USED: "Last used:",
    LOADING: "Loading...",
    SAVE_SUCCESS: "Session saved successfully",
    SWITCH_SUCCESS: "Session switched successfully",
    DELETE_SUCCESS: "Session deleted successfully"
  };

  // src/popup/components/loadingManager.ts
  var LoadingManager = class {
    constructor() {
      this.isLoading = false;
    }
    showLoading() {
      if (!this.isLoading) {
        document.body.classList.add(CSS_CLASSES.LOADING);
        this.isLoading = true;
      }
    }
    hideLoading() {
      if (this.isLoading) {
        document.body.classList.remove(CSS_CLASSES.LOADING);
        this.isLoading = false;
      }
    }
    async withLoading(operation) {
      try {
        this.showLoading();
        return await operation();
      } finally {
        this.hideLoading();
      }
    }
  };

  // src/popup/utils/dom.ts
  function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
  }
  function getElementByIdSafe(id) {
    const element = document.getElementById(id);
    if (!element) {
      throw new Error(`Element not found with id: ${id}`);
    }
    return element;
  }

  // src/popup/components/modalManager.ts
  var ModalManager = class {
    constructor() {
      this.modals = {
        save: getElementByIdSafe("saveModal"),
        rename: getElementByIdSafe("renameModal"),
        delete: getElementByIdSafe("deleteModal"),
        error: getElementByIdSafe("errorModal")
      };
      this.inputs = {
        sessionName: getElementByIdSafe("sessionName"),
        newSessionName: getElementByIdSafe("newSessionName")
      };
      this.setupEventListeners();
    }
    setupEventListeners() {
      const closeButtons = [
        { id: "closeSaveModal", modal: "save" },
        { id: "cancelSave", modal: "save" },
        { id: "closeRenameModal", modal: "rename" },
        { id: "cancelRename", modal: "rename" },
        { id: "closeDeleteModal", modal: "delete" },
        { id: "cancelDelete", modal: "delete" },
        { id: "closeErrorModal", modal: "error" },
        { id: "closeErrorModalBtn", modal: "error" }
      ];
      closeButtons.forEach(({ id, modal }) => {
        getElementByIdSafe(id).addEventListener("click", () => this.hide(modal));
      });
      this.inputs.sessionName.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          getElementByIdSafe("confirmSave").click();
        }
      });
      this.inputs.newSessionName.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          getElementByIdSafe("confirmRename").click();
        }
      });
      document.addEventListener("keydown", (e) => {
        if (e.key === "Escape") {
          this.hideVisible();
        }
        if (e.key === "Enter") {
          if (this.isVisible("delete")) {
            e.preventDefault();
            getElementByIdSafe("confirmDelete").click();
          }
          if (this.isVisible("error")) {
            e.preventDefault();
            getElementByIdSafe("closeErrorModal").click();
          }
        }
      });
      Object.entries(this.modals).forEach(([key, modal]) => {
        modal.addEventListener("click", (e) => {
          if (e.target === modal) this.hide(key);
        });
      });
    }
    showSaveModal(defaultName = "Unnamed Session") {
      this.inputs.sessionName.value = defaultName;
      this.show("save");
      this.inputs.sessionName.focus();
      this.inputs.sessionName.select();
    }
    showRenameModal(currentName) {
      this.inputs.newSessionName.value = currentName;
      this.show("rename");
      this.inputs.newSessionName.focus();
      this.inputs.newSessionName.select();
    }
    showDeleteModal(sessionName) {
      const deleteSessionNameEl = document.getElementById("deleteSessionName");
      if (deleteSessionNameEl) {
        deleteSessionNameEl.textContent = sessionName;
      }
      this.show("delete");
      this.modals.delete.focus();
    }
    showErrorModal(message) {
      const errorMessageEl = document.getElementById("errorMessage");
      if (errorMessageEl) {
        errorMessageEl.textContent = message;
      }
      this.show("error");
      this.modals.error.focus();
    }
    getSaveModalInput() {
      return this.inputs.sessionName.value.trim();
    }
    getRenameModalInput() {
      return this.inputs.newSessionName.value.trim();
    }
    hideSaveModal() {
      this.hide("save");
    }
    hideRenameModal() {
      this.hide("rename");
    }
    hideDeleteModal() {
      this.hide("delete");
    }
    hideErrorModal() {
      this.hide("error");
    }
    hideAllModals() {
      this.hideVisible();
      this.inputs.sessionName.value = "";
      this.inputs.newSessionName.value = "";
    }
    isVisible(modalKey) {
      return this.modals[modalKey]?.classList.contains(CSS_CLASSES.SHOW) || false;
    }
    hideVisible() {
      Object.entries(this.modals).forEach(([key, modal]) => {
        if (modal.classList.contains(CSS_CLASSES.SHOW)) {
          this.hide(key);
        }
      });
    }
    show(modalKey) {
      this.modals[modalKey].classList.add(CSS_CLASSES.SHOW);
    }
    hide(modalKey) {
      this.modals[modalKey].classList.remove(CSS_CLASSES.SHOW);
    }
  };

  // src/shared/utils/date.ts
  function formatDate(timestamp) {
    return new Date(timestamp).toLocaleDateString();
  }

  // src/popup/components/sessionList.ts
  var SessionList = class {
    constructor(container) {
      this.draggedElement = null;
      this.draggedOverElement = null;
      this.container = container;
      this.container.addEventListener("click", this.handleClick.bind(this));
      this.container.addEventListener("dragstart", this.handleDragStart.bind(this));
      this.container.addEventListener("dragover", this.handleDragOver.bind(this));
      this.container.addEventListener("drop", this.handleDrop.bind(this));
      this.container.addEventListener("dragend", this.handleDragEnd.bind(this));
      this.container.addEventListener("dragenter", this.handleDragEnter.bind(this));
      this.container.addEventListener("dragleave", this.handleDragLeave.bind(this));
    }
    setEventHandlers(handlers) {
      this.onSessionClick = handlers.onSessionClick;
      this.onRenameClick = handlers.onRenameClick;
      this.onDeleteClick = handlers.onDeleteClick;
      this.onReorder = handlers.onReorder;
    }
    render(sessions, activeSessions, currentDomain) {
      const domainSessions = sessions.filter((s) => s.domain === currentDomain).sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
      const activeSessionId = activeSessions[currentDomain];
      if (domainSessions.length === 0) {
        this.renderEmptyState();
        return;
      }
      this.renderSessions(domainSessions, activeSessionId);
    }
    renderEmptyState() {
      this.container.innerHTML = `<div class="${CSS_CLASSES.NO_SESSIONS}">${UI_TEXT.NO_SESSIONS}</div>`;
    }
    renderSessions(sessions, activeSessionId) {
      const sessionsHtml = sessions.map((session) => {
        const isActive = session.id === activeSessionId;
        const lastUsed = formatDate(session.lastUsed);
        return `
        <div class="${CSS_CLASSES.SESSION_ITEM} ${isActive ? CSS_CLASSES.ACTIVE : ""}"
             data-session-id="${session.id}"
             draggable="true">
          <div class="drag-handle">\u22EE\u22EE</div>
          <div class="session-info">
            <div class="session-name">${escapeHtml(session.name)}</div>
            <div class="session-meta">${UI_TEXT.LAST_USED} ${lastUsed}</div>
          </div>
          <div class="session-actions">
            <button class="${CSS_CLASSES.SESSION_BTN} rename-btn" data-action="rename" data-session-id="${session.id}">
              \u270F\uFE0F
            </button>
            <button class="${CSS_CLASSES.SESSION_BTN} delete-btn" data-action="delete" data-session-id="${session.id}">
              \u{1F5D1}\uFE0F
            </button>
          </div>
        </div>
      `;
      }).join("");
      this.container.innerHTML = sessionsHtml;
    }
    handleClick(e) {
      const target = e.target;
      if (target.classList.contains(CSS_CLASSES.SESSION_BTN)) {
        e.stopPropagation();
        const action = target.dataset.action;
        const sessionId = target.dataset.sessionId;
        if (!sessionId) return;
        if (action === "rename" && this.onRenameClick) {
          this.onRenameClick(sessionId);
        } else if (action === "delete" && this.onDeleteClick) {
          this.onDeleteClick(sessionId);
        }
        return;
      }
      if (target.classList.contains("drag-handle")) {
        return;
      }
      const sessionItem = target.closest(`.${CSS_CLASSES.SESSION_ITEM}`);
      if (sessionItem && this.onSessionClick) {
        const sessionId = sessionItem.dataset.sessionId;
        if (sessionId) {
          this.onSessionClick(sessionId);
        }
      }
    }
    handleDragStart(e) {
      const target = e.target;
      if (target.classList.contains(CSS_CLASSES.SESSION_ITEM)) {
        this.draggedElement = target;
        target.classList.add("dragging");
        e.dataTransfer.effectAllowed = "move";
        e.dataTransfer.setData("text/html", target.innerHTML);
      }
    }
    handleDragOver(e) {
      e.preventDefault();
      e.dataTransfer.dropEffect = "move";
    }
    handleDragEnter(e) {
      const target = e.target.closest(`.${CSS_CLASSES.SESSION_ITEM}`);
      if (target && target !== this.draggedElement) {
        if (this.draggedOverElement && this.draggedOverElement !== target) {
          this.draggedOverElement.classList.remove("drag-over");
        }
        target.classList.add("drag-over");
        this.draggedOverElement = target;
      }
    }
    handleDragLeave(e) {
      const target = e.target.closest(`.${CSS_CLASSES.SESSION_ITEM}`);
      const relatedTarget = e.relatedTarget;
      if (target && relatedTarget) {
        const leavingToOutside = !target.contains(relatedTarget);
        if (leavingToOutside && target === this.draggedOverElement) {
          target.classList.remove("drag-over");
          this.draggedOverElement = null;
        }
      }
    }
    handleDrop(e) {
      e.preventDefault();
      e.stopPropagation();
      const target = e.target.closest(`.${CSS_CLASSES.SESSION_ITEM}`);
      if (target && this.draggedElement && target !== this.draggedElement) {
        const allItems = Array.from(this.container.querySelectorAll(`.${CSS_CLASSES.SESSION_ITEM}`));
        const draggedIndex = allItems.indexOf(this.draggedElement);
        const targetIndex = allItems.indexOf(target);
        if (draggedIndex < targetIndex) {
          target.after(this.draggedElement);
        } else {
          target.before(this.draggedElement);
        }
        const reorderedIds = Array.from(this.container.querySelectorAll(`.${CSS_CLASSES.SESSION_ITEM}`)).map(
          (item) => item.dataset.sessionId
        );
        if (this.onReorder) {
          this.onReorder(reorderedIds);
        }
      }
    }
    handleDragEnd(e) {
      const target = e.target;
      if (target.classList.contains(CSS_CLASSES.SESSION_ITEM)) {
        target.classList.remove("dragging");
      }
      const allItems = this.container.querySelectorAll(`.${CSS_CLASSES.SESSION_ITEM}`);
      allItems.forEach((item) => item.classList.remove("drag-over"));
      this.draggedElement = null;
      this.draggedOverElement = null;
    }
  };

  // src/popup/utils/defaultValue.ts
  var storedSessionDefaultValue = {
    cookies: [],
    localStorage: {},
    sessionStorage: {}
  };

  // src/shared/constants/messages.ts
  var MESSAGE_ACTIONS = {
    GET_CURRENT_SESSION: "getCurrentSession",
    SWITCH_SESSION: "switchSession",
    CLEAR_SESSION: "clearSession"
  };

  // src/shared/constants/storageKeys.ts
  var STORAGE_KEYS = {
    SESSIONS: "sessions",
    ACTIVE_SESSIONS: "activeSessions"
  };

  // src/shared/utils/idGenerator.ts
  function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  }

  // src/shared/utils/validation.ts
  function validateSessionName(name) {
    const trimmed = name.trim();
    return trimmed || "Unnamed Session";
  }

  // src/popup/services/chromeApi.service.ts
  var ChromeApiService = class {
    async getCurrentTab() {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tabs.length === 0) {
        throw new Error("No active tab found");
      }
      return tabs[0];
    }
    async sendMessage(message) {
      return new Promise((resolve) => {
        chrome.runtime.sendMessage(message, (response) => {
          if (chrome.runtime.lastError) {
            resolve({
              success: false,
              error: chrome.runtime.lastError.message
            });
          } else {
            resolve(response);
          }
        });
      });
    }
    async getStorageData(keys) {
      return chrome.storage.local.get(keys);
    }
    async setStorageData(data) {
      return chrome.storage.local.set(data);
    }
  };

  // src/popup/services/popup.service.ts
  var PopupService = class {
    constructor() {
      this.chromeApi = new ChromeApiService();
      this.state = {
        currentDomain: "",
        currentTab: {},
        sessions: [],
        activeSessions: {},
        currentRenameSessionId: "",
        currentDeleteSessionId: ""
      };
    }
    async initialize() {
      try {
        this.state.currentTab = await this.chromeApi.getCurrentTab();
        if (!this.state.currentTab.url) {
          throw new ExtensionError("Unable to get current tab URL");
        }
        this.state.currentDomain = getDomainFromUrl(this.state.currentTab.url);
        await this.loadStorageData();
        return { ...this.state };
      } catch (error) {
        throw new ExtensionError(handleError(error, "PopupService.initialize"));
      }
    }
    async saveCurrentSession(name) {
      try {
        const validatedName = validateSessionName(name);
        const response = await this.chromeApi.sendMessage({
          action: MESSAGE_ACTIONS.GET_CURRENT_SESSION,
          domain: this.state.currentDomain,
          tabId: this.state.currentTab.id
        });
        if (!response.success) {
          throw new ExtensionError(response.error || "Failed to get current session");
        }
        const storedSession = response.data ?? storedSessionDefaultValue;
        const domainSessions = this.state.sessions.filter((s) => s.domain === this.state.currentDomain);
        const maxOrder = domainSessions.length > 0 ? Math.max(...domainSessions.map((s) => s.order ?? 0)) : -1;
        const newSession = {
          ...storedSession,
          id: generateId(),
          name: validatedName,
          domain: this.state.currentDomain,
          createdAt: Date.now(),
          lastUsed: Date.now(),
          order: maxOrder + 1
        };
        this.state.sessions.push(newSession);
        this.state.activeSessions[this.state.currentDomain] = newSession.id;
        await this.saveStorageData();
        return newSession;
      } catch (error) {
        throw new ExtensionError(handleError(error, "PopupService.saveCurrentSession"));
      }
    }
    async switchToSession(sessionId) {
      try {
        const session = this.state.sessions.find((s) => s.id === sessionId);
        if (!session) {
          throw new ExtensionError("Session not found");
        }
        const response = await this.chromeApi.sendMessage({
          action: MESSAGE_ACTIONS.SWITCH_SESSION,
          sessionData: session,
          tabId: this.state.currentTab.id
        });
        if (!response.success) {
          throw new ExtensionError(response.error || "Failed to switch session");
        }
        this.state.activeSessions[this.state.currentDomain] = sessionId;
        session.lastUsed = Date.now();
        await this.saveStorageData();
      } catch (error) {
        throw new ExtensionError(handleError(error, "PopupService.switchToSession"));
      }
    }
    async createNewSession() {
      try {
        const response = await this.chromeApi.sendMessage({
          action: MESSAGE_ACTIONS.CLEAR_SESSION,
          domain: this.state.currentDomain,
          tabId: this.state.currentTab.id
        });
        if (!response.success) {
          throw new ExtensionError(response.error || "Failed to clear session");
        }
        delete this.state.activeSessions[this.state.currentDomain];
        await this.saveStorageData();
      } catch (error) {
        throw new ExtensionError(handleError(error, "PopupService.createNewSession"));
      }
    }
    async renameSession(sessionId, newName) {
      try {
        const session = this.state.sessions.find((s) => s.id === sessionId);
        if (!session) {
          throw new ExtensionError("Session not found");
        }
        session.name = validateSessionName(newName);
        await this.saveStorageData();
      } catch (error) {
        throw new ExtensionError(handleError(error, "PopupService.renameSession"));
      }
    }
    async deleteSession(sessionId) {
      try {
        this.state.sessions = this.state.sessions.filter((s) => s.id !== sessionId);
        if (this.state.activeSessions[this.state.currentDomain] === sessionId) {
          delete this.state.activeSessions[this.state.currentDomain];
        }
        await this.saveStorageData();
      } catch (error) {
        throw new ExtensionError(handleError(error, "PopupService.deleteSession"));
      }
    }
    async reorderSessions(sessionIds) {
      try {
        const domainSessions = this.state.sessions.filter((s) => s.domain === this.state.currentDomain);
        if (sessionIds.length !== domainSessions.length) {
          throw new ExtensionError("Session count mismatch during reorder operation");
        }
        const sessionIdsSet = new Set(sessionIds);
        const allSessionsPresent = domainSessions.every((session) => sessionIdsSet.has(session.id));
        if (!allSessionsPresent) {
          throw new ExtensionError("Invalid session IDs provided for reorder operation");
        }
        sessionIds.forEach((id, index) => {
          const session = domainSessions.find((s) => s.id === id);
          if (session) {
            session.order = index;
          }
        });
        await this.saveStorageData();
      } catch (error) {
        throw new ExtensionError(handleError(error, "PopupService.reorderSessions"));
      }
    }
    getSession(sessionId) {
      return this.state.sessions.find((s) => s.id === sessionId);
    }
    getState() {
      return { ...this.state };
    }
    setState(newState) {
      this.state = { ...this.state, ...newState };
    }
    async loadStorageData() {
      try {
        const result = await this.chromeApi.getStorageData([
          STORAGE_KEYS.SESSIONS,
          STORAGE_KEYS.ACTIVE_SESSIONS
        ]);
        this.state.sessions = result[STORAGE_KEYS.SESSIONS] || [];
        this.state.activeSessions = result[STORAGE_KEYS.ACTIVE_SESSIONS] || {};
        const migrationNeeded = await this.migrateLegacySessions();
        if (migrationNeeded) {
          await this.saveStorageData();
        }
      } catch (error) {
        console.error("Error loading storage data:", error);
        this.state.sessions = [];
        this.state.activeSessions = {};
      }
    }
    migrateLegacySessions() {
      let migrationPerformed = false;
      const sessionsByDomain = /* @__PURE__ */ new Map();
      this.state.sessions.forEach((session) => {
        if (!sessionsByDomain.has(session.domain)) {
          sessionsByDomain.set(session.domain, []);
        }
        sessionsByDomain.get(session.domain).push(session);
      });
      sessionsByDomain.forEach((sessions) => {
        sessions.forEach((session, index) => {
          if (session.order === void 0) {
            session.order = index;
            migrationPerformed = true;
          }
        });
      });
      return migrationPerformed;
    }
    async saveStorageData() {
      await this.chromeApi.setStorageData({
        [STORAGE_KEYS.SESSIONS]: this.state.sessions,
        [STORAGE_KEYS.ACTIVE_SESSIONS]: this.state.activeSessions
      });
    }
  };

  // src/popup/index.ts
  var PopupController = class {
    constructor() {
      this.loadingManager = new LoadingManager();
      this.modalManager = new ModalManager();
      this.popupService = new PopupService();
      this.currentSiteElement = getElementByIdSafe("currentSite");
      this.saveBtn = getElementByIdSafe("saveBtn");
      this.newSessionBtn = getElementByIdSafe("newSessionBtn");
      this.sessionList = new SessionList(getElementByIdSafe("sessionsList"));
      this.setupSessionListHandlers();
      this.setupEventListeners();
    }
    async initialize() {
      try {
        this.modalManager.hideAllModals();
        const state = await this.loadingManager.withLoading(async () => {
          return await this.popupService.initialize();
        });
        this.currentSiteElement.textContent = state.currentDomain;
        this.renderSessionsList();
      } catch (error) {
        this.showError(handleError(error, "PopupController.initialize"));
      }
    }
    getServiceInstance() {
      return this.popupService;
    }
    setupEventListeners() {
      this.saveBtn.addEventListener("click", () => this.handleSaveClick());
      this.newSessionBtn.addEventListener("click", () => this.handleNewSessionClick());
      getElementByIdSafe("confirmSave").addEventListener("click", () => this.handleConfirmSave());
      getElementByIdSafe("confirmRename").addEventListener("click", () => this.handleConfirmRename());
      getElementByIdSafe("confirmDelete").addEventListener("click", () => this.handleConfirmDelete());
    }
    setupSessionListHandlers() {
      this.sessionList.setEventHandlers({
        onSessionClick: (sessionId) => this.handleSessionSwitch(sessionId),
        onRenameClick: (sessionId) => this.handleRenameClick(sessionId),
        onDeleteClick: (sessionId) => this.handleDeleteClick(sessionId),
        onReorder: (sessionIds) => this.handleReorder(sessionIds)
      });
    }
    async handleSaveClick() {
      this.modalManager.showSaveModal();
    }
    async handleConfirmSave() {
      try {
        const name = this.modalManager.getSaveModalInput();
        await this.loadingManager.withLoading(async () => {
          await this.popupService.saveCurrentSession(name);
        });
        this.modalManager.hideSaveModal();
        this.renderSessionsList();
      } catch (error) {
        this.showError(handleError(error, "save session"));
      }
    }
    async handleNewSessionClick() {
      try {
        await this.loadingManager.withLoading(async () => {
          await this.popupService.createNewSession();
        });
        this.renderSessionsList();
      } catch (error) {
        this.showError(handleError(error, "create new session"));
      }
    }
    async handleSessionSwitch(sessionId) {
      try {
        await this.loadingManager.withLoading(async () => {
          await this.popupService.switchToSession(sessionId);
        });
        this.renderSessionsList();
      } catch (error) {
        this.showError(handleError(error, "switch session"));
      }
    }
    handleRenameClick(sessionId) {
      const session = this.popupService.getSession(sessionId);
      if (session) {
        this.popupService.setState({ currentRenameSessionId: sessionId });
        this.modalManager.showRenameModal(session.name);
      }
    }
    async handleConfirmRename() {
      try {
        const newName = this.modalManager.getRenameModalInput();
        const sessionId = this.popupService.getState().currentRenameSessionId;
        if (newName && sessionId) {
          await this.popupService.renameSession(sessionId, newName);
          this.renderSessionsList();
        }
        this.modalManager.hideRenameModal();
      } catch (error) {
        this.showError(handleError(error, "rename session"));
      }
    }
    handleDeleteClick(sessionId) {
      const session = this.popupService.getSession(sessionId);
      if (session) {
        this.popupService.setState({ currentDeleteSessionId: sessionId });
        this.modalManager.showDeleteModal(session.name);
      }
    }
    async handleConfirmDelete() {
      try {
        const sessionId = this.popupService.getState().currentDeleteSessionId;
        if (sessionId) {
          await this.popupService.deleteSession(sessionId);
          this.renderSessionsList();
        }
        this.modalManager.hideDeleteModal();
      } catch (error) {
        this.showError(handleError(error, "delete session"));
      }
    }
    async handleReorder(sessionIds) {
      try {
        await this.popupService.reorderSessions(sessionIds);
      } catch (error) {
        this.showError(handleError(error, "reorder sessions"));
      }
    }
    renderSessionsList() {
      const state = this.popupService.getState();
      this.sessionList.render(state.sessions, state.activeSessions, state.currentDomain);
    }
    showError(message) {
      console.error("Popup error:", message);
      this.modalManager.showErrorModal(message);
    }
  };
  document.addEventListener("DOMContentLoaded", async () => {
    console.log("Session Switcher popup loaded");
    const controller = new PopupController();
    await controller.initialize();
    const service = controller.getServiceInstance();
    const state = service.getState();
    let currentDomain = state.currentDomain;
    const tabActivatedListener = async (activeInfo) => {
      const tab = await chrome.tabs.get(activeInfo.tabId);
      if (tab.url) {
        const newDomain = getDomainFromUrl(tab.url);
        if (newDomain !== currentDomain) {
          currentDomain = newDomain;
          await controller.initialize();
        }
      }
    };
    const tabUpdatedListener = async (_, changeInfo, tab) => {
      if (changeInfo.status === "complete" && tab.url) {
        const newDomain = getDomainFromUrl(tab.url);
        if (newDomain !== currentDomain) {
          currentDomain = newDomain;
          await controller.initialize();
        }
      }
    };
    chrome.tabs.onActivated.addListener(tabActivatedListener);
    chrome.tabs.onUpdated.addListener(tabUpdatedListener);
    const cleanup = () => {
      chrome.tabs.onActivated.removeListener(tabActivatedListener);
      chrome.tabs.onUpdated.removeListener(tabUpdatedListener);
    };
    window.addEventListener("beforeunload", cleanup);
    window.addEventListener("unload", cleanup);
  });
})();
