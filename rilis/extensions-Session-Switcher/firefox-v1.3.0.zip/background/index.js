"use strict";
var SessionSwitcher = (() => {
  // src/shared/constants/storageKeys.ts
  var STORAGE_KEYS = {
    SESSIONS: "sessions",
    ACTIVE_SESSIONS: "activeSessions"
  };

  // src/shared/utils/errorHandling.ts
  var ExtensionError = class extends Error {
    constructor(message, code) {
      super(message);
      this.code = code;
      this.name = "ExtensionError";
    }
  };
  function handleError(error, context) {
    console.error(`Error in ${context}:`, error);
    if (error instanceof ExtensionError) {
      return error.message;
    }
    if (error instanceof Error) {
      return error.message;
    }
    return "An unexpected error occurred";
  }

  // src/background/handlers/cookie.handler.ts
  var CookieHandler = class {
    async getCookiesForDomain(domain) {
      try {
        const stores = await chrome.cookies.getAllCookieStores();
        const allCookies = [];
        const currentDomain = domain.split(":")[0];
        for (const store of stores) {
          const cookies = await chrome.cookies.getAll({ storeId: store.id });
          const domainCookies = cookies.filter((cookie) => {
            const slicedCookieDomain = cookie.domain.startsWith(".") ? cookie.domain.slice(1) : cookie.domain;
            return slicedCookieDomain === currentDomain || slicedCookieDomain === `www.${currentDomain}` || currentDomain.endsWith(slicedCookieDomain);
          });
          allCookies.push(...domainCookies);
        }
        return allCookies;
      } catch (error) {
        console.error("Error getting cookies for domain:", domain, error);
        return [];
      }
    }
    async clearCookiesForDomain(domain) {
      const cookies = await this.getCookiesForDomain(domain);
      const clearPromises = cookies.map(async (cookie) => {
        try {
          await chrome.cookies.remove({
            url: this.buildCookieUrl(cookie, domain),
            name: cookie.name,
            storeId: cookie.storeId
          });
        } catch (error) {
          console.warn("Failed to remove cookie:", cookie.name, error);
        }
      });
      await Promise.all(clearPromises);
    }
    async restoreCookies(cookies, domain) {
      const restorePromises = cookies.map(async (cookie) => {
        try {
          const cookieDetails = this.prepareCookieForRestore(cookie, domain);
          await chrome.cookies.set(cookieDetails);
        } catch (error) {
          console.warn("Failed to restore cookie:", cookie.name, error);
        }
      });
      await Promise.all(restorePromises);
    }
    buildCookieUrl(cookie, fallbackDomain) {
      const protocol = cookie.secure ? "https" : "http";
      let domain = cookie.domain;
      if (domain.startsWith(".")) {
        domain = domain.slice(1);
      }
      if (!domain && fallbackDomain) {
        domain = fallbackDomain;
      }
      if (!domain) {
        throw new Error(`Invalid domain for cookie ${cookie.name}: ${cookie.domain}`);
      }
      const path = cookie.path || "/";
      return `${protocol}://${domain}${path}`;
    }
    prepareCookieForRestore(cookie, fallbackDomain) {
      const url = this.buildCookieUrl(cookie, fallbackDomain);
      const cookieDetails = {
        url,
        name: cookie.name,
        value: cookie.value,
        path: cookie.path,
        secure: cookie.secure,
        httpOnly: cookie.httpOnly,
        storeId: cookie.storeId
      };
      if (cookie.domain && cookie.domain.startsWith(".")) {
        cookieDetails.domain = cookie.domain;
      }
      if (!cookie.session && cookie.expirationDate) {
        cookieDetails.expirationDate = cookie.expirationDate;
      }
      if (cookie.sameSite && cookie.sameSite !== "unspecified") {
        cookieDetails.sameSite = cookie.sameSite;
      }
      return cookieDetails;
    }
  };

  // src/background/services/storageData.service.ts
  function extractStorageData() {
    try {
      const localStorageData = {};
      const sessionStorageData = {};
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key) {
          const value = localStorage.getItem(key);
          if (value !== null) {
            localStorageData[key] = value;
          }
        }
      }
      for (let i = 0; i < sessionStorage.length; i++) {
        const key = sessionStorage.key(i);
        if (key) {
          const value = sessionStorage.getItem(key);
          if (value !== null) {
            sessionStorageData[key] = value;
          }
        }
      }
      return {
        localStorage: localStorageData,
        sessionStorage: sessionStorageData
      };
    } catch (error) {
      console.error("Error extracting storage data:", error);
      return { localStorage: {}, sessionStorage: {} };
    }
  }
  function injectStorageData(localData, sessionData) {
    try {
      localStorage.clear();
      sessionStorage.clear();
      Object.entries(localData).forEach(([key, value]) => {
        localStorage.setItem(key, value);
      });
      Object.entries(sessionData).forEach(([key, value]) => {
        sessionStorage.setItem(key, value);
      });
      return true;
    } catch (error) {
      console.error("Error injecting storage data:", error);
      return false;
    }
  }
  function clearStorage() {
    try {
      localStorage.clear();
      sessionStorage.clear();
      return true;
    } catch (error) {
      console.error("Error clearing storage:", error);
      return false;
    }
  }

  // src/background/handlers/storage.handler.ts
  var StorageHandler = class {
    async getStorageData(tabId) {
      try {
        const results = await chrome.scripting.executeScript({
          target: { tabId },
          func: extractStorageData
        });
        return results?.[0]?.result || { localStorage: {}, sessionStorage: {} };
      } catch (error) {
        console.error("Error getting storage data:", error);
        return { localStorage: {}, sessionStorage: {} };
      }
    }
    async restoreStorageData(tabId, data) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId },
          func: injectStorageData,
          args: [data.localStorage, data.sessionStorage]
        });
      } catch (error) {
        throw new ExtensionError(`Failed to restore storage data: ${error}`);
      }
    }
    async clearStorageData(tabId) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId },
          func: clearStorage
        });
      } catch (error) {
        throw new ExtensionError(`Failed to clear storage data: ${error}`);
      }
    }
  };

  // src/background/handlers/session.handler.ts
  var SessionHandler = class {
    constructor() {
      this.cookieHandler = new CookieHandler();
      this.storageHandler = new StorageHandler();
    }
    async getCurrentSession(domain, tabId) {
      try {
        const [cookies, storageData] = await Promise.all([
          this.cookieHandler.getCookiesForDomain(domain),
          this.storageHandler.getStorageData(tabId)
        ]);
        return {
          cookies,
          localStorage: storageData.localStorage,
          sessionStorage: storageData.sessionStorage
        };
      } catch (error) {
        throw new ExtensionError(`Failed to get current session: ${error}`);
      }
    }
    async switchToSession(sessionData, tabId) {
      const { domain, cookies, localStorage: localStorage2, sessionStorage: sessionStorage2 } = sessionData;
      try {
        await this.cookieHandler.clearCookiesForDomain(domain);
        await Promise.all([
          this.cookieHandler.restoreCookies(cookies, domain),
          this.storageHandler.restoreStorageData(tabId, {
            localStorage: localStorage2,
            sessionStorage: sessionStorage2
          })
        ]);
        await chrome.tabs.reload(tabId);
      } catch (error) {
        throw new ExtensionError(`Failed to switch session: ${error}`);
      }
    }
    async clearSession(domain, tabId) {
      try {
        await Promise.all([
          this.cookieHandler.clearCookiesForDomain(domain),
          this.storageHandler.clearStorageData(tabId)
        ]);
        await chrome.tabs.reload(tabId);
      } catch (error) {
        throw new ExtensionError(`Failed to clear session: ${error}`);
      }
    }
  };

  // src/shared/constants/messages.ts
  var MESSAGE_ACTIONS = {
    GET_CURRENT_SESSION: "getCurrentSession",
    SWITCH_SESSION: "switchSession",
    CLEAR_SESSION: "clearSession"
  };

  // src/shared/constants/requiredPermission.ts
  var REQUIRED_PERMISSIONS = [
    "storage",
    "tabs",
    "cookies",
    "activeTab",
    "scripting"
  ];

  // src/background/services/message.service.ts
  var MessageService = class {
    constructor() {
      this.sessionHandler = new SessionHandler();
    }
    handleMessage(message, _, sendResponse) {
      this.checkPermissions().then(() => {
        return this.processMessage(message, sendResponse);
      }).catch((error) => {
        const errorMessage = handleError(error, "MessageService.handleMessage");
        sendResponse({ success: false, error: errorMessage });
      });
      return true;
    }
    async checkPermissions() {
      try {
        const permissions = await chrome.permissions.getAll();
        this.validateRequiredPermissions(permissions);
        this.validateOriginPermissions(permissions);
      } catch (error) {
        throw error;
      }
    }
    validateRequiredPermissions(permissions) {
      for (const permission of REQUIRED_PERMISSIONS) {
        if (!permissions.permissions?.includes(permission)) {
          throw new Error("Data access permission is required.");
        }
      }
    }
    validateOriginPermissions(permissions) {
      const origins = permissions.origins || [];
      if (origins.length === 0) {
        throw new Error("Data access permission is required.");
      }
      const hasBroadAccess = origins.some(
        (origin) => origin === "<all_urls>" || origin === "*://*/*" || origin === "http://*/*" || origin === "https://*/*"
      );
      if (!hasBroadAccess) {
        throw new Error("Data access permission is required.");
      }
    }
    async processMessage(message, sendResponse) {
      switch (message.action) {
        case MESSAGE_ACTIONS.GET_CURRENT_SESSION:
          await this.handleGetCurrentSession(message, sendResponse);
          break;
        case MESSAGE_ACTIONS.SWITCH_SESSION:
          await this.handleSwitchSession(message, sendResponse);
          break;
        case MESSAGE_ACTIONS.CLEAR_SESSION:
          await this.handleClearSession(message, sendResponse);
          break;
        default:
          sendResponse({ success: false, error: "Unknown action" });
      }
    }
    async handleGetCurrentSession(message, sendResponse) {
      const sessionData = await this.sessionHandler.getCurrentSession(message.domain, message.tabId);
      sendResponse({ success: true, data: sessionData });
    }
    async handleSwitchSession(message, sendResponse) {
      await this.sessionHandler.switchToSession(message.sessionData, message.tabId);
      sendResponse({ success: true });
    }
    async handleClearSession(message, sendResponse) {
      await this.sessionHandler.clearSession(message.domain, message.tabId);
      sendResponse({ success: true });
    }
  };

  // src/background/index.ts
  var messageService = new MessageService();
  chrome.runtime.onStartup.addListener(() => {
    console.log("Session Switcher extension started");
  });
  chrome.runtime.onInstalled.addListener((details) => {
    console.log("Session Switcher extension installed/updated", details);
    if (details.reason === "install") {
      chrome.storage.local.set({
        [STORAGE_KEYS.SESSIONS]: [],
        [STORAGE_KEYS.ACTIVE_SESSIONS]: {}
      });
    }
  });
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    return messageService.handleMessage(message, sender, sendResponse);
  });
})();
